think-police
============

An entry for the Kivy 2014 App Contest

Heavily inspired by the game Papers, Please (http://papersplea.se/) and the novel 1984 ThinkPolice is a game of moral decisions. You operate as an agent of the Thought Police to exterminate ThoughtCriminals while trying to maintain your own sanity in these dark times.
